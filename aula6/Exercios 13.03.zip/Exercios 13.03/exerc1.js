//1. Crie uma interface com 3 botões, e ao pressionar os botões irá aparecer uma mensagem em prompt informando sua ação.
function acao1 (){
    alert ("você clicou no botão 1")
}
    function acao2 (){
        alert ("você clicou no botão 2")
    }
        function acao3 (){ 
            alert ("você clicou no botão 3")
}
